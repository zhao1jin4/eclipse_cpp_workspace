/* 3.c */
#include "b.h"
#include "c.h"

void function_three() {
}
