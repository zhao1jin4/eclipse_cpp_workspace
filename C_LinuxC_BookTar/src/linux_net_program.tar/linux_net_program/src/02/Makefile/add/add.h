/* add.h */
#ifdef __ADD_H__
#define __ADD_H__
extern int add_int(int a, int b);
extern float add_float(float a, float b);

#endif /*__ADD_H__*/

