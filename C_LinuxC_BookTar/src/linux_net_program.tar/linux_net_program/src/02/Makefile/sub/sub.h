/* sub.h */
#ifdef __ADD_H__
#define __ADD_H__
extern float sub_float(float a, float b);
extern int sub_int(int a, int b);
#endif /*__ADD_H__*/
