


sem_t sem_create();
int sem_signal();
int sem_release();
int sem_destory();
int sem_getvalue();
int sem_setvalue();
