int max(int x,int y);
int min(int x,int y);
int avg(int x,int y);
