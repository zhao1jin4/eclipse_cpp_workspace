int avg(int x,int y)
{
return (x+y)/2;
}
