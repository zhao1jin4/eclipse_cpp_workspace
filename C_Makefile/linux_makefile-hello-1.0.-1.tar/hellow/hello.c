#include <stdio.h>
#include "mymath.h"
int main(int argc, char *argv[])
{
	printf("Hello, world\n");
	printf("avg is =%d",avg(10,20));
	printf("avg is =%d",	avg(10,20));	

	printf("min is =%d",	min(10,20));	
	return 0;
}
